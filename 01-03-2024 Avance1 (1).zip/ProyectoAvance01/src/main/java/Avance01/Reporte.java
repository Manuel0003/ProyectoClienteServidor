
package Avance01;


public interface Reporte {
    void tipoReporte();
    void imprimirReporte();
    void reporteventadiaria();
    void reporteproductossinstock();
    void reporteexistenciasproducto();
    void reportemercaderiaantigua();
    void reportedepedidos();
}
