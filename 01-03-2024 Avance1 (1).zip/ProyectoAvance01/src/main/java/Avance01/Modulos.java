
package Avance01;


public abstract class Modulos {

    
   public abstract String Modulo_Reporte();
   public abstract String Modulo_Pago();
   public abstract String Modulo_RegistroPedidos();
   public abstract String Modulo_RegistroCliente();
   public abstract String Modulo_RegistroEmpleado();
   public abstract String Modulo_GestionProductos();
   
   
}

